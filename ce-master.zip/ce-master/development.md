# Compiling

## Using webpack


## Using framework

Install and use as npm package 


## Using docker (deprecated)

Run `docker-compose up transpile`
